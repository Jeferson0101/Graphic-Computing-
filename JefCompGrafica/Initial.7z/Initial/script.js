"use strict";

var canvas = document.getElementById("tela");
var ctx = canvas.getContext("2d");